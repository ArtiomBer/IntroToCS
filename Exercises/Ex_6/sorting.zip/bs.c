#include <stdio.h>

void swap(int arr[], int i, int j) {
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

void bubbleSort(int arr[], int size) {
    for (int i = 0; i < size-1; i++) {
        for (int j = 0; j < size-1-i; j++) {
            if (arr[j] > arr[j+1]) {
                swap(arr, j, j+1);
            }
        }
    }
}

void bubbleSortComplexity(int arr[], int size) {
    int iterations = 0, operations = 0, swaps = 0;
    for (int i = 0; i < size-1; i++) {
        iterations++;
        for (int j = 0; j < size-1-i; j++) {
            operations++;
            if (arr[j] > arr[j+1]) {
                swap(arr, j, j+1);
                swaps++;
            }
        }
    }
    printf("%d : %d : %d\n", size, iterations, operations);
}

void bubbleSortEfficient(int arr[], int size) {
    int isSwapped = 0;
    for (int i = 0; i < size-1; i++) {
        for (int j = 0; j < size-1-i; j++) {
            if (arr[j] > arr[j+1]) {
                swap(arr, j, j+1);
                isSwapped = 1;
            }
        }
        if (!isSwapped) {
            break;
        }
        isSwapped = 0;
    }
}

void bubbleSortEfficientComplexity(int arr[], int size) {
    int iterations = 0, operations = 0;
    int isSwapped = 0;
    for (int i = 0; i < size-1; i++) {
        iterations++;
        for (int j = 0; j < size-1-i; j++) {
            operations++;
            if (arr[j] > arr[j+1]) {
                swap(arr, j, j+1);
                isSwapped = 1;
            }
        }
        if (!isSwapped) {
            break;
        }
        isSwapped = 0;
    }
    printf("%d : %d : %d\n", size, iterations, operations);
}

void printArr(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        if (i) {
            printf(" ");
        }
        printf("%d",arr[i]);
    }
    printf("\n");
}

void main() {
    int arr[] = {5,7,6,9,2,4,8,3,1};
    int size = sizeof(arr) / sizeof(int);
    printArr(arr, size);
    bubbleSort(arr, size);
    printArr(arr, size);
}
