#include <stdio.h>

void printArr(int arr[], int start, int stop) {
	if (start < stop) {
		printf("|%d|", arr[start]);
	}
	for (int i = start + 1; i < stop; i++) {
        printf("%d|", arr[i]);
	}
	printf("\n");
    if (start < stop) {
		printf("|%d|", start);
	}
	for (int i = start + 1; i < stop; i++) {
		printf("%d|", i);
	}
    printf("\n");
}

void swap(int arr[], int i, int j) {
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

void quicksort(int arr[], int start, int stop) {
    printf("-------------- start: [%d-%d] ---------------   V\n", start, stop - 1);
    if (start >= stop - 1) {
        printf("-------------- return: [%d-%d] --------------   ^\n", start, stop - 1);
        return;
    }
    printArr(arr, start, stop);
    int pivot = start;
    printf("----------- pivot selection: %d ------------\n", arr[pivot]);
    int i = start + 1, j = stop - 1;
    while (i < j) {
        while (arr[i] <= arr[pivot] && i < stop - 1) {
            i++;
        }
        while (arr[j] > arr[pivot]) {
            j--;
        }
        if (i < j) {
            printf("--------- swap: %d <-> %d [%d <-> %d] ---------\n", arr[i], arr[j], i, j);
            swap(arr, i, j);
        }
    }
    printf("------ pivot back: %d <-> %d [%d <-> %d] ------\n", arr[pivot], arr[j], pivot, j);
    swap(arr, pivot, j);
    printArr(arr, start, stop);
    quicksort(arr, start, j);
    printArr(arr, start, stop);
    quicksort(arr, i, stop);
    printArr(arr, start, stop);
    printf("-------------- return: [%d-%d] --------------   ^\n", start, stop - 1);
}

void qsort(int arr[], int start, int stop) {
    printf("-------------- start: [%d-%d] ---------------   V\n", start, stop - 1);
    if (start >= stop - 1) {
        printf("-------------- return: [%d-%d] --------------   ^\n", start, stop - 1);
		return;
	}
    printArr(arr, start, stop);
    // int middle = (start + stop) / 2;
	// swap(arr, start, middle);
    int pivot = start;
    printf("----------- pivot selection: %d ------------\n", arr[pivot]);

    int j = start;
    for (int i = start + 1; i < stop; i++)  {
        if (arr[i] < arr[pivot]) {
            j++;
            printArr(arr, start, stop);
            printf("---------------- %d/%d [%d/%d] ----------------\n", arr[j], arr[i], j, i);
            if (i != j) {
                printf("--------- swap: %d <-> %d [%d <-> %d] ---------\n", arr[i], arr[j], i, j);
                swap(arr, i, j);
            }
        }
    }
    printf("------ pivot back: %d <-> %d [%d <-> %d] ------\n", arr[pivot], arr[j], pivot, j);
	swap(arr, start, j);
    printArr(arr, start, stop);
	qsort(arr, start, j);
    printArr(arr, start, stop);
	qsort(arr, j + 1, stop);
    printArr(arr, start, stop);
    printf("-------------- return: [%d-%d] --------------   ^\n", start, stop - 1);
}


int main() {
    int arr[] = {5,6,1,8,9,2,4,7,0,3};
    // int arr[] = {9,8,7,6,5,4,3,2,1,0};
    // int arr[] = {0,1,2,3,4,5,6,7,8,9};
    // quicksort(arr, 0, 10);
    qsort(arr, 0, 10);
}
