#include <stdio.h>
#include <stdlib.h>

void printArr(int arr[], int start, int stop) {
	if (start < stop) {
		printf("|%d|", arr[start]);
	}
	for (int i = start + 1; i < stop; i++) {
		printf("%d|", arr[i]);
	}
	printf("\n");
    if (start < stop) {
		printf("|%d|", start);
	}
	for (int i = start + 1; i < stop; i++) {
		printf("%d|", i);
	}
    printf("\n");
}

void merge_copy(int arr[], int start, int middle, int stop) {
    int size = stop - start;
    int* tmp = malloc(size * sizeof(int));
    if (!tmp) {
        printf("Error while sorting :(\n");
        return;
    }
    int left = start;
    int right = middle;
    for (int i = 0; i < size; i++) {
        if (right >= stop) {
            tmp[i] = arr[left++];
            continue;
        }
        if (left >= middle) {
            tmp[i] = arr[right++];
            continue;
        }
        if (arr[left] <= arr[right]) {
            tmp[i] = arr[left++];
        } else {
            tmp[i] = arr[right++];
        }
    }
    for (int i = 0; i < size; i++) {
        arr[start + i] = tmp[i];
    }
    free(tmp);
}

void copy_merge(int arr[], int start, int middle, int stop) {
    int size = stop - start;
    int* tmp = malloc(size * sizeof(int));
    if (!tmp) {
        printf("Error while sorting :(\n");
        return;
    }
    for (int i = 0; i < size; i++) {
        tmp[i] = arr[start + i];
    }
    int left = 0;
    int right = middle - start;
    for (int i = start; i < stop; i++) {
        if (right >= stop - start) {
            arr[i] = tmp[left++];
            continue;
        }
        if (left >= middle - start) {
            arr[i] = tmp[right++];
            continue;
        }
        if (tmp[left] <= tmp[right]) {
            arr[i] = tmp[left++];
        } else {
            arr[i] = tmp[right++];
        }
    }
    free(tmp);
}

void mergesort(int arr[], int start, int stop) {
    printf("------------ start: [%d-%d] -------------   V\n", start, stop - 1);
    if (start >= stop - 1) {
        printf("------------ return: [%d-%d] ------------   ^\n", start, stop - 1);
        return;
    }
    printArr(arr, start, stop);
    int middle = (start + stop) / 2;
    printf("---------- split: [%d-%d][%d-%d] ----------\n", start, middle - 1, middle, stop - 1);
    mergesort(arr, start, middle);
    mergesort(arr, middle, stop);
    // merge_copy(arr, start, middle, stop);
    copy_merge(arr, start, middle, stop);
    printf("---------- merge: [%d-%d][%d-%d] ----------\n", start, middle - 1, middle, stop - 1);
    printArr(arr, start, stop);
    printf("----------- return: [%d-%d] -------------   ^\n", start, stop - 1);
}

int main() {
    // int arr[] = {0,1,2,3,4,5,6,7,8,9};
    // int arr[] = {9,8,7,6,5,4,3,2,1,0};
    int arr[] = {5,6,1,8,9,2,4,7,0,3};
    mergesort(arr, 0, 10);
}
