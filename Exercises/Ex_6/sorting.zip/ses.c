#include <stdio.h>

void printArr(int arr[], int start, int stop) {
	if (start < stop) {
		printf("|%d|", arr[start]);
	}
	for (int i = start + 1; i < stop; i++) {
		printf("%d|", arr[i]);
	}
	printf("\n");
    if (start < stop) {
		printf("|%d|", start);
	}
	for (int i = start + 1; i < stop; i++) {
		printf("%d|", i);
	}
    printf("\n");
}

void swap(int arr[], int i, int j) {
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

int findMinIndex(int arr[], int start, int stop) {
    int index = start;
    for (int i = start + 1; i < stop; i++) {
        if (arr[i] < arr[index]) {
            index = i;
        }
    }
    return index;
}

void selectionsort(int arr[], int start, int stop) {
    if (start >= stop - 1) {
        printf("----------- start  (finish) -----------   V\n");
        printf("----------- return (finish) -----------   ^\n");
        return;
    }
    printf("------------- start [%d-%d] -------------   V\n", start, stop - 1);
    printArr(arr, start, stop);
    int minIndex = findMinIndex(arr, start, stop);
    printf("------- min at [%d-%d] is: %d [%d] --------\n", start, stop - 1, arr[minIndex], minIndex);
    printf("------- swap: %d <-> %d [%d <-> %d] -------\n", arr[start], arr[minIndex], start, minIndex);
    swap(arr, start, minIndex);
    printArr(arr, start, stop);
    selectionsort(arr, start + 1, stop);
    printf("------------ return [%d-%d] -------------   ^\n", start, stop - 1);
}

int main() {
    int arr[] = {5,6,1,8,9,2,4,7,0,3};
    // int arr[] = {9,8,7,6,5,4,3,2,1,0};
    // int arr[] = {0,1,2,3,4,5,6,7,8,9};
	selectionsort(arr, 0, 10);
    printArr(arr, 0, 10);
}
