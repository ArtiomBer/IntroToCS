#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// bubble sort
// selection sort
// quick sort
void swap(int arr[], int i, int j) {
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

// selection sort
int findMinIndex(int arr[], int start, int stop) {
    int index = start;
    for (int i = start + 1; i < stop; i++) {
        if (arr[i] < arr[index]) {
            index = i;
        }
    }
    return index;
}

void bubblesort(int arr[], int size) {
    int isSwapped = 0;
    for (int i = 0; i < size-1; i++) {
        for (int j = 0; j < size-1-i; j++) {
            if (arr[j] > arr[j+1]) {
                swap(arr, j, j+1);
                isSwapped = 1;
            }
        }
        if (!isSwapped) {
            break;
        }
        isSwapped = 0;
    }
}

void selectionsort(int arr[], int start, int stop) {
    if (start >= stop) {
        return;
    }
    int minIndex = findMinIndex(arr, start, stop);
    swap(arr, start, minIndex);
    selectionsort(arr, start + 1, stop);
}

void quicksort(int arr[], int start, int stop) {
    if (start >= stop - 1) {
        return;
    }
    int pivot = start;
    int i = start + 1, j = stop - 1;
    while (i < j) {
        while (arr[i] <= arr[pivot] && i < stop - 1) {
            i++;
        }
        while (arr[j] > arr[pivot]) {
            j--;
        }
        if (i < j) {
            swap(arr, i, j);
        }
    }
    swap(arr, pivot, j);
    quicksort(arr, start, j);
    quicksort(arr, i, stop);
}

void merge(int arr[], int start, int middle, int stop) {
    int size = stop - start;
    int* tmp = malloc(size * sizeof(int));
    if (!tmp) {
        printf("Error while sorting :(\n");
        return;
    }
    for (int i = 0; i < size; i++) {
        tmp[i] = arr[start + i];
    }
    int left = 0;
    int right = middle - start;
    for (int i = start; i < stop; i++) {
        if (right >= stop - start) {
            arr[i] = tmp[left++];
            continue;
        }
        if (left >= middle - start) {
            arr[i] = tmp[right++];
            continue;
        }
        if (tmp[left] <= tmp[right]) {
            arr[i] = tmp[left++];
        } else {
            arr[i] = tmp[right++];
        }
    }
    free(tmp);
}

void mergesort(int arr[], int start, int stop) {
    if (start >= stop - 1) {
        return;
    }
    int middle = (start + stop) / 2;
    mergesort(arr, start, middle);
    mergesort(arr, middle, stop);
    merge(arr, start, middle, stop);
}

#define SIZE 30000

void init_best(int arr[], int size) {
	srand(time(NULL));
    for (int i = 0; i < size; i++) {
        arr[i] = i;
    }
}

void init_worst(int arr[], int size) {
	srand(time(NULL));
    for (int i = 0; i < size; i++) {
        arr[i] = size - i;
    }
}

void init_random(int arr[], int size) {
	srand(time(NULL));
    for (int i = 0; i < size; i++) {
        arr[i] = rand();
    }
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("wrong number of keys (!= 2)\n");
        return 0;
    }

    int arr[SIZE];
    if (strcmp(argv[2], "bc") == 0) {
        init_best(arr, SIZE);
    } else if (strcmp(argv[2], "wc") == 0) {
        init_worst(arr, SIZE);
    } else if (strcmp(argv[2], "rc") == 0) {
        init_random(arr, SIZE);
    } else {
        printf("second key is wrong (!= wc/bc/rc)\n");
        return 0;
    }

    clock_t begin = clock();

    if (strcmp(argv[1], "bs") == 0) {
        bubblesort(arr, SIZE);
    } else if (strcmp(argv[1], "ses") == 0) {
        selectionsort(arr, 0, SIZE);
    } else if (strcmp(argv[1], "qs") == 0) {
        quicksort(arr, 0, SIZE);
    } else if (strcmp(argv[1], "ms") == 0) {
        mergesort(arr, 0, SIZE);
    } else {
        printf("first key is wrong (!= bs/ses/qs/ms)\n");
    }

    clock_t end = clock();

    double diff = (double)(end - begin);
    double seconds = diff / CLOCKS_PER_SEC;
    double millis = 1000.0 * seconds;
    double micros = 1000.0 * millis;

    printf("Time spent (clocks): %.f\n", diff);
    printf("Time spent (seconds): %.f\n", seconds);
    printf("Time spent (milli seconds): %.f\n", millis);
    printf("Time spent (micro seconds): %.f\n", micros);

    return 0;
}
